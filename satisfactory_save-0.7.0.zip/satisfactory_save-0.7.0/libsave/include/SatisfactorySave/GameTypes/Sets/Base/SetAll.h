#pragma once

#include "../StructSet.h"
#include "../UInt32Set.h"
