from pathlib import Path

import satisfactory_save as s

save = s.SaveGame(Path('test.sav'))
print(save)
